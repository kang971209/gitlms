package com.project.lms.config;

public class WebConfig {

}
