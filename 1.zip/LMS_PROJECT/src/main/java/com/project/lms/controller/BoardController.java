package com.project.lms.controller;

public class BoardController {

}
