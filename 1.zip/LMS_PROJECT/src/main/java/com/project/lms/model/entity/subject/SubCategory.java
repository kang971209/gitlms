package com.project.lms.model.entity.subject;

import lombok.Data;

@Data
public class SubCategory {
	private Long category_no;
	private String category_name;
}
