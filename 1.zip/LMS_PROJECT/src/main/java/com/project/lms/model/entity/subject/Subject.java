package com.project.lms.model.entity.subject;

import lombok.Data;

@Data
public class Subject {
	private Long subject_no;
}
